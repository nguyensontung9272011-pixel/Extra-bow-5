package com.example.extrabows;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Draws the 3D "spirit_bow_display" model so that the bow aims along the owner's look direction. */
public class SpiritBowRenderer extends EntityRenderer<SpiritBow> {
    private static final ResourceLocation TEX =
            ResourceLocation.fromNamespaceAndPath(ExtraBows.MODID, "textures/item/spirit_parts.png");
    private static final float SCALE = 0.9F;

    private final ItemRenderer itemRenderer;

    public SpiritBowRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.itemRenderer = context.getItemRenderer();
    }

    @Override
    public ResourceLocation getTextureLocation(SpiritBow entity) {
        return TEX;
    }

    @Override
    public void render(SpiritBow entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        float yaw = Mth.rotLerp(partialTick, entity.yRotO, entity.getYRot());
        float pitch = Mth.lerp(partialTick, entity.xRotO, entity.getXRot());
        Vec3 f = Vec3.directionFromRotation(pitch, yaw);                       // forward
        Vec3 u = new Vec3(0.0D, 1.0D, 0.0D).subtract(f.scale(f.y));            // up, perpendicular to forward
        if (u.lengthSqr() < 1.0E-4D) u = new Vec3(0.0D, 0.0D, 1.0D);
        u = u.normalize();
        Vec3 s = u.cross(f);

        // The model's bow aims to its upper-left (-x,+y). Rotate so that direction -> forward
        // and the perpendicular (+x,+y) -> up.
        float k = 0.7071F;
        Matrix4f rot = new Matrix4f(
                (float) ((u.x - f.x) * k), (float) ((u.y - f.y) * k), (float) ((u.z - f.z) * k), 0.0F,
                (float) ((u.x + f.x) * k), (float) ((u.y + f.y) * k), (float) ((u.z + f.z) * k), 0.0F,
                (float) s.x, (float) s.y, (float) s.z, 0.0F,
                0.0F, 0.0F, 0.0F, 1.0F);

        poseStack.pushPose();
        poseStack.mulPose(rot);
        poseStack.scale(SCALE, SCALE, SCALE);
        itemRenderer.renderStatic(new ItemStack(ExtraBows.SPIRIT_DISPLAY.get()), ItemDisplayContext.NONE,
                LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, poseStack, buffer,
                entity.level(), entity.getId());
        poseStack.popPose();
    }
}
