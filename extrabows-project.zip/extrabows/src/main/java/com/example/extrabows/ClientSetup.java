package com.example.extrabows;

import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = ExtraBows.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            register(ExtraBows.LONG_BOW.get(), ExtraBows.LONG_BOW.get().getDrawTicks());
            register(ExtraBows.RAPID_BOW.get(), ExtraBows.RAPID_BOW.get().getDrawTicks());
            register(ExtraBows.MULTI_BOW.get(), ExtraBows.MULTI_BOW.get().getDrawTicks());
            register(ExtraBows.TRINITY_BOW.get(), TrinityBowItem.DRAW_TICKS);
        });
    }

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ExtraBows.LASER_ARROW.get(), NoopRenderer::new); // laser = particles
        event.registerEntityRenderer(ExtraBows.SPIRIT_BOW.get(), SpiritBowRenderer::new);
    }

    private static void register(Item bow, int drawTicks) {
        ItemProperties.register(bow, ResourceLocation.withDefaultNamespace("pull"),
                (stack, level, entity, seed) -> {
                    if (entity == null || entity.getUseItem() != stack) return 0.0F;
                    return (float) (CustomBowItem.USE_DURATION - entity.getUseItemRemainingTicks()) / drawTicks;
                });
        ItemProperties.register(bow, ResourceLocation.withDefaultNamespace("pulling"),
                (stack, level, entity, seed) ->
                        entity != null && entity.isUsingItem() && entity.getUseItem() == stack ? 1.0F : 0.0F);
    }
}
